from django.apps import AppConfig


class RoniConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'roni'
