from django.urls import path
from . import views

urlpatterns = [
    path('roni/', views.hidup, name='roni'),
]