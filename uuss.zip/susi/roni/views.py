from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

def index(request):
  template = loader.get_template('index.html')
  return HttpResponse(template.render())
def no(request):
  template = loader.get_template('no.html')
  return HttpResponse(template.render())
def ada(request):
  template = loader.get_template('ada.html')
  return HttpResponse(template.render())
def adu(request):
  template = loader.get_template('adu.html')
  return HttpResponse(template.render())